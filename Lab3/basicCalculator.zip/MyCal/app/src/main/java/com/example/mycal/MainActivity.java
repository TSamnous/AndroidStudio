package com.example.mycal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView resultTv,solutionTv;
    MaterialButton buttonAc,buttonC,buttonDot;
    MaterialButton button00,button0,button1,button2,button3,button4,button5,button6,button7,button8,button9;
    MaterialButton buttonPercent,buttonMultiply,buttonDivide,buttonAdd,buttonSub,buttonEquals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultTv= findViewById(R.id.resultTv);
        solutionTv= findViewById(R.id.solutionTv);

        assignId(buttonAc,R.id.button_ac);
        assignId(buttonC,R.id.button_c);
        assignId(buttonDot,R.id.button_dot);
        assignId(button00,R.id.button_00);
        assignId(button0,R.id.button_0);
        assignId(button1,R.id.button_1);
        assignId(button2,R.id.button_2);
        assignId(button3,R.id.button_3);
        assignId(button4,R.id.button_4);
        assignId(button5,R.id.button_5);
        assignId(button6,R.id.button_6);
        assignId(button7,R.id.button_7);
        assignId(button8,R.id.button_8);
        assignId(button9,R.id.button_9);
        assignId(buttonPercent,R.id.button_percent);
        assignId(buttonMultiply,R.id.button_multiply);
        assignId(buttonDivide,R.id.button_divide);
        assignId(buttonAdd,R.id.button_add);
        assignId(buttonSub,R.id.button_sub);
        assignId(buttonEquals,R.id.button_equals);


    }

    void assignId(MaterialButton btn,int id){
        btn= findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        MaterialButton button= (MaterialButton) v;
        String buttonText =button.getText().toString();
        String dataToCalculate = solutionTv.getText().toString();


        if(buttonText.equals("AC")){
            solutionTv.setText(" ");
            resultTv.setText(" ");
            return;
        }




        if(buttonText.equals("=")){
            solutionTv.setText(resultTv.getText());
            return;
        }

// Code for button click
// ...

        if (buttonText.equals("C")) {
            if (dataToCalculate.length() > 0) {
                dataToCalculate = dataToCalculate.substring(0, dataToCalculate.length() - 1);
            }
        } else {
            dataToCalculate = dataToCalculate + buttonText;
        }

        solutionTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 48); // Set text size 48sp for solution TextView
        solutionTv.setText(dataToCalculate);

        String finalResult = getResult(dataToCalculate);

        if (!finalResult.equals("Err")) {
            resultTv.setText(finalResult);

            if (buttonText.equals("=")) {
                resultTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 48); // Set text size 48sp for result TextView after pressing the equals operator
                solutionTv.setVisibility(View.INVISIBLE); // Hide the solution TextView after pressing the equals operator
            } else {
                resultTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24); // Set text size 24sp for result TextView for other buttons
                solutionTv.setVisibility(View.VISIBLE); // Show the solution TextView for other buttons
            }
        } else {
            // Handle error case
            resultTv.setText("");
            solutionTv.setVisibility(View.VISIBLE); // Show the solution TextView in case of an error
        }




    }

    String getResult(String data) {
        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            Object evalResult = context.evaluateString(scriptable, data, "Javascript", 1, null);

            if (evalResult instanceof Undefined) {
                return "Err"; // Return an error message if the result is undefined
            }

            String finalResult = evalResult.toString();
            if (finalResult.endsWith(".0")) {
                finalResult = finalResult.replace(".0", "");
            }
            return finalResult;
        } catch (Exception e) {
            return "Err";
        } finally {
            Context.exit(); // Make sure to exit the JavaScript context
        }



    }

}