package com.example.laligascore;

public class DisplayActivity {
}
