package com.example.laligascore;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

import android.view.inputmethod.InputMethodManager;
import android.content.Context;


public class MainActivity extends AppCompatActivity {

    private EditText shothome,shotaway,sothome,sotaway,poshome,posaway;

    private EditText foulhome,foulaway,ychome,ycaway,rchome,rcaway;

    private MaterialButton clearbtn,submitbtn;

    private MaterialButton homeplusbtn,homeminusbtn,awayplusbtn,awayminusbtn;

    private int homescore = 0;
    private int awayscore= 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //textView & EditText
        EditText shothome    =    findViewById(R.id.shothome);
        EditText shotaway    =    findViewById(R.id.shotaway);
        EditText sothome     =    findViewById(R.id.sothome);
        EditText sotaway     =    findViewById(R.id.sotaway);
        EditText poshome     =    findViewById(R.id.poshome);
        EditText posaway     =    findViewById(R.id.posaway);
        EditText foulhome    =    findViewById(R.id.foulhome);
        EditText foulaway    =    findViewById(R.id.foulaway);
        EditText ychome      =    findViewById(R.id.ychome);
        EditText ycaway      =    findViewById(R.id.ycaway);
        EditText rchome      =    findViewById(R.id.rchome);
        EditText rcaway      =    findViewById(R.id.rcaway);

        EditText homescoretv = findViewById(R.id.homescoretv);
        EditText awayscoretv = findViewById(R.id.awayscoretv);

        homescoretv.setText(String.valueOf(homescore));
        awayscoretv.setText(String.valueOf(awayscore));

        //buttons
        clearbtn    =    findViewById(R.id.clearbtn);
        submitbtn   =    findViewById(R.id.submitbtn);
        homeplusbtn =   findViewById(R.id.homeplusbtn);
        homeminusbtn=   findViewById(R.id.homeminusbtn);
        awayplusbtn=    findViewById(R.id.awayplusbtn);
        awayminusbtn=   findViewById(R.id.awayminusbtn);

        //Layouts and others
        View rootView = findViewById(android.R.id.content);
        RelativeLayout rootLayout = findViewById(R.id.rootLayout);
        ImageView homeSelectedLogo = findViewById(R.id.homeSelectedLogo);
        ImageView awaySelectedLogo = findViewById(R.id.awayselectedLogo);
        HorizontalScrollView homesv = findViewById(R.id.homesv);
        HorizontalScrollView awaysv = findViewById(R.id.awaysv);
        LinearLayout teamscrollview = findViewById(R.id.teamscrollview);
        LinearLayout awayTeamContainer = findViewById(R.id.awayTeamContainer);
        LinearLayout homeTeamContainer = findViewById(R.id.homeTeamContainer);
        LinearLayout homeSelectedLayout = findViewById(R.id.homeSelectedLayout);
        LinearLayout awaySelectedLayout = findViewById(R.id.awaySelectedLayout);






        //possession
// Add a TextWatcher to the home possession EditText
        poshome.addTextChangedListener(new TextWatcher() {
            private boolean isProgrammaticChange = false;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not used
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (isProgrammaticChange) {
                    // Ignore the event if it's triggered programmatically
                    isProgrammaticChange = false;
                    return;
                }

                // Get the value entered in the home possession EditText
                String poshomeTxt = poshome.getText().toString().trim();

                // Check if the home possession value is not empty
                if (!poshomeTxt.isEmpty()) {
                    // Convert the home possession value to an integer
                    int poshomeVal = Integer.parseInt(poshomeTxt);

                    // Check if the home possession is within the valid range
                    if (poshomeVal < 0 || poshomeVal > 100) {
                        // Clear the input and show an error message
                        poshome.setText("");
                        poshome.setError("Enter a value between 0 and 100");
                        return;
                    }

                    // Calculate the away possession based on the entered home possession
                    int posawayVal = 100 - poshomeVal;

                    // Update the away possession EditText programmatically
                    isProgrammaticChange = true;
                    posaway.setText(String.valueOf(posawayVal));

                    // Move the cursor to the end of the text
                    poshome.setSelection(poshome.getText().length());
                }
            }
        });

// Add a TextWatcher to the away possession EditText
        posaway.addTextChangedListener(new TextWatcher() {
            private boolean isProgrammaticChange = false;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not used
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (isProgrammaticChange) {
                    // Ignore the event if it's triggered programmatically
                    isProgrammaticChange = false;
                    return;
                }

                // Get the value entered in the away possession EditText
                String posawayTxt = posaway.getText().toString().trim();

                // Check if the away possession value is not empty
                if (!posawayTxt.isEmpty()) {
                    // Convert the away possession value to an integer
                    int posawayVal = Integer.parseInt(posawayTxt);

                    // Check if the away possession is within the valid range
                    if (posawayVal < 0 || posawayVal > 100) {
                        // Clear the input and show an error message
                        posaway.setText("");
                        posaway.setError("Enter a value between 0 and 100");
                        return;
                    }

                    // Calculate the home possession based on the entered away possession
                    int poshomeVal = 100 - posawayVal;

                    // Update the home possession EditText programmatically
                    isProgrammaticChange = true;
                    poshome.setText(String.valueOf(poshomeVal));

                    // Move the cursor to the end of the text
                    posaway.setSelection(posaway.getText().length());
                }
            }
        });

        //validation of Shots on Target
        shothome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No implementation needed
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String shothomeTxt = editable.toString();
                String sothomeTxt = sothome.getText().toString();

                int shothomeVal = 0;
                int sothomeVal = 0;

                if (!shothomeTxt.isEmpty()) {
                    shothomeVal = Integer.parseInt(shothomeTxt);
                }

                if (!sothomeTxt.isEmpty()) {
                    sothomeVal = Integer.parseInt(sothomeTxt);
                }

                if (shothomeVal < sothomeVal) {
                    sothomeVal = shothomeVal;
                    sothome.setText(String.valueOf(sothomeVal));
                }
            }
        });

        sothome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No implementation needed
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String shothomeTxt = shothome.getText().toString();
                String sothomeTxt = editable.toString();

                int shothomeVal = 0;
                int sothomeVal = 0;

                if (!shothomeTxt.isEmpty()) {
                    shothomeVal = Integer.parseInt(shothomeTxt);
                }

                if (!sothomeTxt.isEmpty()) {
                    sothomeVal = Integer.parseInt(sothomeTxt);
                }

                if (sothomeVal > shothomeVal) {
                    sothomeVal = shothomeVal;
                    sothome.setText(String.valueOf(sothomeVal));
                }
            }
        });

        shotaway.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No implementation needed
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String shotawayTxt = editable.toString();
                String sotawayTxt = sotaway.getText().toString();

                int shotawayVal = 0;
                int sotawayVal = 0;

                if (!shotawayTxt.isEmpty()) {
                    shotawayVal = Integer.parseInt(shotawayTxt);
                }

                if (!sotawayTxt.isEmpty()) {
                    sotawayVal = Integer.parseInt(sotawayTxt);
                }

                if (shotawayVal < sotawayVal) {
                    sotawayVal = shotawayVal;
                    sotaway.setText(String.valueOf(sotawayVal));
                }
            }
        });

        sotaway.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No implementation needed
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String shotawayTxt = shotaway.getText().toString();
                String sotawayTxt = editable.toString();

                int shotawayVal = 0;
                int sotawayVal = 0;

                if (!shotawayTxt.isEmpty()) {
                    shotawayVal = Integer.parseInt(shotawayTxt);
                }

                if (!sotawayTxt.isEmpty()) {
                    sotawayVal = Integer.parseInt(sotawayTxt);
                }

                if (sotawayVal > shotawayVal) {
                    sotawayVal = shotawayVal;
                    sotaway.setText(String.valueOf(sotawayVal));
                }
            }
        });


        //Clear Button
        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText homescoretv = findViewById(R.id.homescoretv);
                EditText awayscoretv = findViewById(R.id.awayscoretv);
                EditText poshome = findViewById(R.id.poshome);
                EditText posaway = findViewById(R.id.posaway);

                homeSelectedLogo.setImageResource(0);
                awaySelectedLogo.setImageResource(0);

                homeSelectedLayout.setVisibility(View.GONE);
                awaySelectedLayout.setVisibility(View.GONE);

                homesv.setVisibility(View.VISIBLE);
                awaysv.setVisibility(View.VISIBLE);

                homescoretv.setText("0");
                awayscoretv.setText("0");
                shothome.setText("");
                shotaway.setText("");
                sothome.setText("");
                sotaway.setText("");
                poshome.setText("");
                posaway.setText("");
                foulhome.setText("");
                foulaway.setText("");
                ychome.setText("");
                ycaway.setText("");
                rchome.setText("");
                rcaway.setText("");


            }
        });

        //Team Selection

        for(int i=0; i< homeTeamContainer.getChildCount(); i++){
            View childView = homeTeamContainer.getChildAt(i);
            if(childView instanceof ImageView){
                ImageView imageView=(ImageView) childView;

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectHomeTeam(imageView);
                    }
                });
            }
        }


        for(int j=0; j < awayTeamContainer.getChildCount(); j++){
            View childView = awayTeamContainer.getChildAt(j);
            if(childView instanceof ImageView){
                ImageView imageView=(ImageView) childView;

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectAwayTeam(imageView);
                    }
                });
            }
        }

        //Hide Keyboard
        rootLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
            }
        });




// score Add buttons

        homeplusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                homescore++;
                homescoretv.setText(String.valueOf(homescore));
            }
        });

        homeminusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(homescore > 0) {
                    homescore--;
                    homescoretv.setText(String.valueOf(homescore));
                }
            }
        });

        awayplusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                awayscore++;
                awayscoretv.setText(String.valueOf(awayscore));

            }
        });

        awayminusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(awayscore> 0) {
                    awayscore--;
                    awayscoretv.setText(String.valueOf(awayscore));
                }
            }

        });
    }

    //---------------------------------------------------------------------------------------- methods ----------------------------------------------------------------------------------------//
    private void selectHomeTeam(ImageView homeTeamLogo){
        Drawable selectedLogoDrawable = homeTeamLogo.getDrawable();

        ImageView homeSelectedLogo = findViewById(R.id.homeSelectedLogo);
        homeSelectedLogo.setImageDrawable(selectedLogoDrawable);

        HorizontalScrollView teamScrollView = findViewById(R.id.homesv);
        teamScrollView.setVisibility(View.GONE);

        LinearLayout homeSelectedLayout = findViewById(R.id.homeSelectedLayout);
        homeSelectedLayout.setVisibility(View.VISIBLE);
    }


    private void selectAwayTeam(ImageView awayTeamLogo) {
        Drawable selectedLogoDrawable = awayTeamLogo.getDrawable();

        ImageView awaySelectedLogo = findViewById(R.id.awayselectedLogo);
        awaySelectedLogo.setImageDrawable(selectedLogoDrawable);

        HorizontalScrollView teamScrollView = findViewById(R.id.awaysv);
        LinearLayout awaySelectedLayout = findViewById(R.id.awaySelectedLayout);

        teamScrollView.setVisibility(View.GONE);
        awaySelectedLayout.setVisibility(View.VISIBLE);
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
